ForgotPassword
==============

A Simple Spring MVC forgot password with JAVA Mail.
